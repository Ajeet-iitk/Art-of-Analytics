Best Bowling Economy Innings
Best Bowling Strike Rate Innings
Fastest Centuries
Fastest Fifties
Most Dot Balls Innings
Most Fours Innings
Most Runs
Most Runs Conceded Innings
Most Runs Over
Most Sixes Innings
Most Wickets